KYLE IN THE SHOWER
How to open and play

OPEN THE GAME (WINDOWS)
1. Download shower race.zip.
2. Right-click the ZIP and choose "Extract All...".
3. Open the extracted folder and double-click shower race.html.
   If needed, use "Open with" and select Chrome or Edge.
Open the extracted HTML file rather than opening it inside the ZIP.
The game includes its artwork and sounds and works offline.
A loading screen stays up until the current artwork is ready.
The original character art has been removed from the game.

SET UP A RACE
1. Paste 2-10 names into "Paste your racer names", one per line or separated
   by commas, then click "Use names". The racer count updates automatically.
   You can also use the minus/plus buttons and edit individual lineup names.
2. Use "Randomize looks" for a different cast. There are 12 ordinary comic
   character looks; Kyle is excluded from the racer pool.
   CHARACTER LOOKS controls how many looks are available.
3. Use "Randomize order" to shuffle the starting lanes.
4. Set RACE LENGTH from 1-90 seconds. A separate 3-second countdown comes first.
5. Click "Start the race" once the artwork is ready.
Settings are saved when your browser permits local storage.

THE CHASE
Racers move automatically across a 200-metre shower-room course.
Their arms and legs keep cycling in an energetic running style like Kyle's,
including in longer races. Head and body artwork stay together.
Kyle runs just ahead for about 3 seconds in a normal race, then accelerates
out of view and waits at the finish. Short race settings scale this opening.
Every racer slips exactly once, then resumes running.
Small shaded bubbles cover the racers' swim shorts. Kyle stays fully clothed.
Exactly one randomly selected racer per race has a fat body type.
The winner is chosen randomly. Body size, names, looks and lanes do not
change the odds. You do not steer or control the racers.

THE FINISH
The winner pushes off and makes a tucked airborne leap toward Kyle.
Dedicated catch artwork shows Kyle supporting the winner's back and knees,
bending to absorb the landing, then standing with the winner held in his arms.
The results card appears after the catch and hold.
Click "Let's slip again" or "Race again" for another random race.

CONTROLS
- Pause/resume with the pause button.
- Use 1x/2x to change race and animation playback speed.
- Use the speaker button for sound, which starts off.
- Use the expand button for a larger race view.
- Space starts or pauses; R starts another race after one finishes.
  Keyboard shortcuts do not apply while editing a field.

SHARE WITH FRIENDS
Send shower race.zip, then have friends extract it and open shower race.html.
A file:/// address only points to your own computer and cannot be shared
as a playable web link.

FILES INCLUDED
- shower race.html: the complete game, artwork and sounds.
- README - How to Play.txt: this guide.
